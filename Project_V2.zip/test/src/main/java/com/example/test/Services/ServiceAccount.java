package com.example.test.Services;


import com.example.test.AccountManegment.Account;
import com.example.test.AccountManegment.AccountLogin;
import com.example.test.Repository.AccountsRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ServiceAccount {

    private List<Account> accountsLogin;

    public ServiceAccount() {
        this.accountsLogin = new ArrayList<>();
    }

    AccountsRepository accountsRepository = new AccountsRepository();

    public List<Account> getAllAccounts() {
        return accountsRepository.getAllAccounts();
    }

    public Account signUp(Account newp) {
       return accountsRepository.addAccount(newp);
    }

    public String logIn(AccountLogin ac) {
        if (accountsRepository.findUserByData(ac)) {
            Account account = accountsRepository.getAccountByEmail(ac.getEmail());
            accountsRepository.setAccountLogin(account);
            return "Welcome Back "+account.getName();
        }
        return "Sorry , Invalid Data";
    }

}
