package com.example.test.Services;


import com.example.test.Module.Freind;
import com.example.test.Module.Product;
import com.example.test.NotificationManegment.Notifications;
import com.example.test.OrdersManegment.CompoundOrder;
import com.example.test.OrdersManegment.Order;
import com.example.test.OrdersManegment.SingleOrder;
import com.example.test.Repository.AccountsRepository;
import com.example.test.Repository.ProductRepositry;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ServiceOrder {
    private List<Product> products;
    Notifications notifications = new Notifications();
    ProductRepositry repositry = new ProductRepositry();
    AccountsRepository accountsRepository = new AccountsRepository();

    public String oneOrder(String id) {
        if (repositry.getAllProducts().size() > Integer.parseInt(id)) {
            Order singleOrder = new SingleOrder(repositry.getProductById(id));
            return notifications.messagePlaceOrder(repositry.getProductById(id), accountsRepository.getAccountLogin());
        }
        else {
            return notifications.messagefailedOrder();
        }
    }

    public String manyOrders(List<Freind> users) {
        for (Freind f: users) {
            if (repositry.getAllProducts().size() > Integer.parseInt(f.getIdOfProduct())) {
                Order manyOrder = new CompoundOrder(repositry.getProductById(f.getIdOfProduct()));
                return notifications.messageOfPlaceCompoundOrder(repositry.getProductById(f.getIdOfProduct()), f.getUsername(), accountsRepository.getAccountLogin());
            }

        }
        return notifications.messagefailedOrder();
    }

    public List<String> compoundOrder(List<Freind> users) {
        List<String> sends = new ArrayList<>();
        List<String> failds = new ArrayList<>();
        for (Freind f: users) {
            if (repositry.getAllProducts().size() > Integer.parseInt(f.getIdOfProduct())) {
                Order manyOrder = new CompoundOrder(repositry.getProductById(f.getIdOfProduct()));
//                manyOrder.placeOrder();
                sends.add(notifications.placefreindOrder(f, repositry.getProductById(f.getIdOfProduct()).getName()));
                return sends;
            }
            else {
                failds.add(notifications.messagefailedOrder());
            }
        }
        return  failds;
    }

}
