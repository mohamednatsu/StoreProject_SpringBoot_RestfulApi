package com.example.test.Services;

import com.example.test.Module.Product;
import com.example.test.Repository.ProductRepositry;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class ServiceProduct {

    private ProductRepositry productRepositry = new ProductRepositry();

    public List<Product> getAllProducts() {
        return productRepositry.getAllProducts();
    }

    public Product getProductById(String id) {
        return  productRepositry.getProductById(id);
    }

    public Product addProduct(Product newp) {
        return  productRepositry.addProduct(newp);
    }
}
