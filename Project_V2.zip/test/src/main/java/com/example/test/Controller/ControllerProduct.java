package com.example.test.Controller;

import com.example.test.AccountManegment.Account;
import com.example.test.Module.Product;
import com.example.test.Services.ServiceProduct;
import jakarta.websocket.server.PathParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ControllerProduct {

    // bussnies logic
    private final ServiceProduct serviceProduct;

    @Autowired
    public ControllerProduct(ServiceProduct serviceProduct) {
        this.serviceProduct = serviceProduct;
    }

    @GetMapping("/")
    public String home() {
        return "<h2>Welcome in my Store</h2>";
    }


    @GetMapping("/products")
    public List<Product> getAllProducts() {
        return serviceProduct.getAllProducts();
    }


    @GetMapping("/product/{id}")
    public ResponseEntity<Product> getProductById(@PathVariable("id") String id) {
        Product product = serviceProduct.getProductById(id);

        if (product == null) {
            return new ResponseEntity<Product> (HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Product> (product, HttpStatus.OK);
    }


    @PostMapping("/product/add")
    public Product addProduct(@RequestBody Product newProduct) {
        return serviceProduct.addProduct(newProduct);
    }
}
