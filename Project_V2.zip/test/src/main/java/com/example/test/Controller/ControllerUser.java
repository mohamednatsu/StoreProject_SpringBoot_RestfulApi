package com.example.test.Controller;


import com.example.test.AccountManegment.Account;
import com.example.test.AccountManegment.AccountLogin;
import com.example.test.Services.ServiceAccount;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class ControllerUser {
    ServiceAccount serviceUser = new ServiceAccount();

    @Autowired
    public ControllerUser(ServiceAccount serviceUser) {
        this.serviceUser = serviceUser;
    }

    @GetMapping("/accounts")
    public List<Account> getAllAccounts() {
        return serviceUser.getAllAccounts();
    }

    @PostMapping("/signup")
    public Account signUp(@RequestBody Account newuser) {
        return serviceUser.signUp(newuser);
    }

    @PostMapping("/login")
    public String logIn(@RequestBody AccountLogin acc) {
        return serviceUser.logIn(acc);
    }

}
