package com.example.test.OrdersManegment;

import com.example.test.Module.Product;

import java.util.List;

public class SingleOrder implements Order{
    List<Product> products;
    Product product;
    private int shippingfee = 0;
    public SingleOrder(Product p) {
        this.product = p;
    }
    @Override
    public void placeOrder() {
        products.add(product);
    }

    @Override
    public void cancelOrder() {
        products.remove(product);
    }
}
