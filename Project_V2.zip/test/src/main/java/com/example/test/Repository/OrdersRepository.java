package com.example.test.Repository;

import com.example.test.Module.Product;

import java.util.List;

public class OrdersRepository {
    private List<Product> products;


}
