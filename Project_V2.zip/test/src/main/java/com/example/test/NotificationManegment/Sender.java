package com.example.test.NotificationManegment;

public class Sender {
    NotificationSender sender = (NotificationSender) new Object();
    Notifications notifications = new Notifications();
    public Sender(NotificationSender sender) {
        this.sender = sender;
    }

    public String sendNotification() {
        return sender.send("test");
    }
}
