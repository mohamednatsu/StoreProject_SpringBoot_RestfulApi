package com.example.test.NotificationManegment;

public class Email implements NotificationSender{
    @Override
    public String send(String message) {
        return message;
    }
}
