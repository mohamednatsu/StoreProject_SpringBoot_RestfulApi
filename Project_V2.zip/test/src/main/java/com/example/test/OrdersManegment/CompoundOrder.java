package com.example.test.OrdersManegment;

import com.example.test.Module.Product;

import java.util.List;

public class CompoundOrder implements Order{
    private int shippingfee = 0;
    List<Product> products;
    Product product;
    public CompoundOrder(Product p) {
        this.product = p;
    }

    public CompoundOrder(List<Product> products) {
        this.products = products;
    }

    @Override
    public void placeOrder() {
        products.add(product);
    }

    @Override
    public void cancelOrder() {
        products.remove(product);
    }
}
