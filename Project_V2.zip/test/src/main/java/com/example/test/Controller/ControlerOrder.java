package com.example.test.Controller;

import com.example.test.AccountManegment.Account;
import com.example.test.Module.Freind;
import com.example.test.Module.Product;
import com.example.test.Services.ServiceOrder;
import com.example.test.Services.ServiceProduct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.function.BiFunction;

@RestController
public class ControlerOrder {
    private final ServiceOrder serviceOrder;

    @Autowired
    public ControlerOrder(ServiceOrder serviceOrder) {
        this.serviceOrder = serviceOrder;
    }

    @GetMapping("product/placeorder/{id}")
    public String placeOrder(@PathVariable("id") String id) {
        return serviceOrder.oneOrder(id);
    }


    @PostMapping("/product/compoundorder/placeorder")
    public List<String> placeCompundOrder(@RequestBody List<Freind> usersOfFriends) {
        return serviceOrder.compoundOrder(usersOfFriends);
    }
}
