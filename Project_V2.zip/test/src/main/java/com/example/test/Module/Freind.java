package com.example.test.Module;



public class Freind {
    private String username;
    private String idOfProduct;

    public Freind(String username, String idOfProduct) {
        this.username = username;
        this.idOfProduct = idOfProduct;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getIdOfProduct() {
        return idOfProduct;
    }

    public void setIdOfProduct(String idOfProduct) {
        this.idOfProduct = idOfProduct;
    }
}
