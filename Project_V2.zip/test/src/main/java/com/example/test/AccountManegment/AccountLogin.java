package com.example.test.AccountManegment;

public class AccountLogin {
    private String password;
    private String email;

    public AccountLogin(String password, String email) {
        this.password = password;
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public String getEmail() {
        return email;
    }
}

