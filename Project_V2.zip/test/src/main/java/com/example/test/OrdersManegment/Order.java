package com.example.test.OrdersManegment;

public interface Order {
    public void placeOrder();
    public void cancelOrder();
}
