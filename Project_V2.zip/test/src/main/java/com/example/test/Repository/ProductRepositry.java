package com.example.test.Repository;

import com.example.test.Module.Product;
import org.springframework.boot.autoconfigure.data.jpa.JpaRepositoriesAutoConfiguration;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;


@Repository
public class ProductRepositry {
    private List<Product> products;

    public List<Product> getAllProducts() {
        products = new ArrayList<>();

        products.add(new Product("Phone","1"));
        products.add(new Product("Laptob","2"));
        products.add(new Product("Mobile","3"));
        products.add(new Product("TV","4"));
        products.add(new Product("Gameplay","5"));

        return products;
    }

    public Product getProductById(String id) {
        Predicate<Product> byId = p -> p.getId().equals(id);
        return  filterProducts(byId);
    }

    private Product filterProducts(Predicate<Product> st) {
        return getAllProducts().stream().filter(st).findFirst().orElse(null);
    }

    public Product addProduct(Product newp) {
        newp.setId(newp.getId());
        newp.setName(newp.getName());
        return newp;
    }

    public boolean findproduct(String id) {
        Product p = new Product();
        return products.equals(p.getId());
    }
}
