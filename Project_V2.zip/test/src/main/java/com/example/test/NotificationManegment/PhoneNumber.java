//package com.example.test.NotificationManegment;
//
//public class PhoneNumber implements NotificationSender{
//
//    @Override
//    public void send(String message) {
//
//    }
//}
