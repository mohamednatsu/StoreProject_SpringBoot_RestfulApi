package com.example.test.NotificationManegment;

import com.example.test.AccountManegment.Account;
import com.example.test.Module.Freind;
import com.example.test.Module.Product;

import java.util.ArrayList;
import java.util.List;

public class Notifications {
    public String messagePlaceOrder(Product p, Account ac) {

        return "Dear "+ac.getName()+" , your booking of the "+p.getName()+" is confirmed. thanks for using our store :)";
    }

    public String messagefailedOrder() {
        return "Sorry Product Will be not Found :(";
    }

    public String messageOfPlaceCompoundOrder(Product p, String username, Account login) {
        return "Dear "+username+" , your Order "+p.getName()+" is booking From freind "+login.getName();
    }

    public String placefreindOrder(Freind fr,  String productname) {

        System.out.println("hello Dear "+ fr.getUsername()+" , your Order "+productname+" is booking From freind ");
            return ("hello Dear "+ fr.getUsername()+" , your Order "+productname+" is booking From freind ");

    }
}
