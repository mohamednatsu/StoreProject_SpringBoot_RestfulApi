package com.example.test.Repository;


import com.example.test.AccountManegment.Account;
import com.example.test.AccountManegment.AccountLogin;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class AccountsRepository {
    private List<Account> accounts;
    private Account loginUser ;

    public AccountsRepository() {
        accounts = new ArrayList<>();
        accounts.add(new Account("Mohamed Salih", 400, "msalhnwr@gmail.com", "01140228412", "msdR55%", "faisel, first faisel, king st,5"));
        accounts.add(new Account("Ahmed Ali", 300, "ahmed@gmail.com", "01140228412", "msdR55%", "faisel, first faisel, king st,5"));
        accounts.add(new Account("Mousa Amir", 500, "mAmir@gmail.com", "01140228412", "msdR55%", "faisel, first faisel, king st,5"));
        accounts.add(new Account("Samar Ahmed", 700, "4samar@gmail.com", "01140228412", "msdR55%", "faisel, first faisel, king st,5"));
    }

    public List<Account> getAllAccounts() {
        return accounts;
    }


    public Account addAccount(Account newp) {
        newp.setName(newp.getName());
        newp.setBalance(newp.getBalance());
        newp.setEmail(newp.getEmail());
        newp.setLocation(newp.getLocation());
        newp.setPassword(newp.getPassword());
        newp.setPhoneNumber(newp.getPhoneNumber());
        return newp;
    }

    public Boolean findUserByData(AccountLogin acc) {
        for (Account ac: accounts) {
            if (ac.getPassword().equals(acc.getPassword()) && ac.getEmail().equals(acc.getEmail()))
                return true;
        }
        return false;
    }

    public Boolean findUserByData(String password, String email) {
        for (Account ac: accounts) {
            if (ac.getPassword().equals(password) && ac.getEmail().equals(email))
                return true;
        }
        return false;
    }

    public Account getAccountByEmail(String email) {
        for (Account ac: accounts) {
            if (ac.getEmail().equals(email)) {
                return ac;
            }
        }
        return null;
    }

    public Account getAccountLogin() {
        return loginUser;
    }

    public void setAccountLogin(Account ac) {
        this.loginUser = ac;
    }
}
