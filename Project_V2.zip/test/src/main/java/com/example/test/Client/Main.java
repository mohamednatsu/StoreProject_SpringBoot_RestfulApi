package com.example.test.Client;

public class Main {
    public void run(){
        System.out.println("Welcome Gooo");
    }
}
