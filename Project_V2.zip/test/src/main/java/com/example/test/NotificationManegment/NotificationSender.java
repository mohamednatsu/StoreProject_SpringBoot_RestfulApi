package com.example.test.NotificationManegment;

public interface NotificationSender {
    public String send(String message);
}
